Both your changes and mine should be one big game
I hope that is, bar some different variable data types it should all be fully incorperated

Fixed the main menu as well, 
added in at least some functionality for all 4 options
Remade the menu, you will love it.

I am still working on the super jazzy background, I commented it off so the program runs, its close to being finished im just a little stuck on it

That should be about it for now
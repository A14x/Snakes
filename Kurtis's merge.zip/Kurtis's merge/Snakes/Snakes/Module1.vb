﻿Module Module1
    Dim worm(99, 99) As Integer 'used to track worm segments x,y in arena
    Dim arena(49, 23) As Char 'used to record what is in the arena x,y
    Dim highscoreValue(9) As Integer 'high score table scores
    Dim highscoreName(9) As String 'high score table names
    Dim wormHeadPointer As Integer 'used to record the current head of the snake in the snake array
    Dim wormTailPointer As Integer 'like the other one but the tail position
    Dim wormDirection As Char 'direction that the snake is moving u, d, l, r
    Dim wormAlive As Boolean 'flags if the snake is alive or dead
    Dim wormGrow As Boolean 'flags if the worm needs to grow
    Dim gameSpeed As Double 'game delay in ms
    Dim score As Integer 'game score
    Dim foodTimer As Integer 'bonus score counts down until it hits 0 or is eaten
    Dim pause As Boolean
    Dim xFood, yFood As Byte
    Dim bonusLevel As Boolean = False
    Dim bonusLevelDone As Boolean = False
    Dim bonusFruitCount As Int16 = 0
    Dim bonusLevelScore As Int16 = 5000
    Dim difficulty As Integer
    Dim menuOption As Integer

    Const forever As Boolean = False 'you are here forever

    '************************************************************************************
    'Procedure to drop food a into the arena
    Sub drop_food()
        Dim x, y As Integer
        Do
            x = Rnd() * 49
            y = Rnd() * 23
        Loop Until (arena(x, y) = " ")
        Console.ForegroundColor() = 10
        If (x = 0 Or 49) Or (y = 0 Or 23) Then
            Console.BackgroundColor = ConsoleColor.Yellow
        Else
            Console.BackgroundColor = ConsoleColor.DarkBlue
        End If
        arena(x, y) = "+"
        Console.SetCursorPosition(x, y)
        Console.Write("+")
        foodTimer = 200
    End Sub

    '**********************************************************************************
    'Procedure to drop random mean walls that noone likes into the arena
    Sub drop_wall()
        Dim x, y, rndwall, probability As Integer
        Select Case difficulty
            Case = 1
                probability = 500
            Case = 2
                probability = 500
            Case = 3
                probability = 250
            Case = 4
                probability = 100
            Case Else
                probability = 500 'failsafe
        End Select
        rndwall = Rnd() * probability
        If rndwall = 0 Then
            Do
                x = Rnd() * 49
                y = Rnd() * 23
            Loop Until (arena(x, y) = " ")
            Console.ForegroundColor = 12
            If (x = 0 Or 49) Or (y = 0 Or 23) Then
                Console.BackgroundColor = ConsoleColor.Yellow
            Else
                Console.BackgroundColor = ConsoleColor.DarkBlue
            End If
            arena(x, y) = "!"
                Console.SetCursorPosition(x, y)
                Console.Write("!")
            End If
    End Sub

    '***********************************************************************************
    'Procedure to initialise all the game variables
    Sub initialise_game()

        'difficulty control
        Dim difSpeed As Integer
        Select Case difficulty
            Case = "1"
                difSpeed = 100
            Case = "2"
                difSpeed = 70
            Case = "3"
                difSpeed = 50
            Case = "4"
                difSpeed = 50
            Case Else
                difSpeed = 100 'failsafe
        End Select

        Dim counterX, counterY As Integer 'Initialise the arena
        For counterX = 0 To 49
            For counterY = 0 To 23
                arena(counterX, counterY) = " "
            Next
        Next
        'Initialise game variables
        gameSpeed = difSpeed
        score = 0
        wormAlive = True
        wormGrow = False
        wormHeadPointer = 4
        wormTailPointer = 1
        wormDirection = "r"
        worm(1, 1) = 5
        worm(1, 2) = 5
        arena(5, 5) = "#"
        worm(2, 1) = 6
        worm(2, 2) = 5
        arena(5, 5) = "#"
        worm(3, 1) = 7
        worm(3, 2) = 5
        arena(7, 5) = "#"
        worm(4, 1) = 8
        worm(4, 2) = 5
        arena(8, 5) = "#"
        difficulty = 0
        menuOption = "0"
        bonusLevel = False
        bonusLevelDone = False
        Console.CursorVisible = False
        Randomize()
        drop_food()
    End Sub

    '*********************************************************************************
    'Proceure to initialise high score table
    Sub initialise_high_score()
        Dim counter As Integer
        For counter = 0 To 9
            highscoreName(counter) = "David Drew"
            highscoreValue(counter) = "0"
        Next
    End Sub

    '**************************************************************************************
    'This is how you make a proper main menu
    Sub Menu_transition()
        Console.CursorVisible = False
        wormGrow = True
        wormDirection = "r"
        worm(wormHeadPointer, 1) = 0
        worm(wormHeadPointer, 2) = 9
        For counter = 0 To 4
            System.Threading.Thread.Sleep(50)
            move_worm()
            wormGrow = True
        Next
        wormGrow = False
        For counter = 0 To 6
            System.Threading.Thread.Sleep(50)
            move_worm()
        Next
        For counter = 0 To 14
            System.Threading.Thread.Sleep(50)
            move_worm()
            wormGrow = True
        Next
        wormDirection = "u"
        For counter = 0 To 3
            System.Threading.Thread.Sleep(50)
            move_worm()
            wormGrow = True
        Next
        wormDirection = "l"
        For counter = 0 To 18
            System.Threading.Thread.Sleep(50)
            move_worm()
            wormGrow = True
        Next
        wormDirection = "u"
        For counter = 0 To 3
            System.Threading.Thread.Sleep(50)
            move_worm()
            wormGrow = True
        Next
        wormDirection = "r"
        For counter = 0 To 19
            System.Threading.Thread.Sleep(50)
            move_worm()
            wormGrow = True
        Next
        Console.BackgroundColor = ConsoleColor.White
        Console.Clear()
        System.Threading.Thread.Sleep(500)
        Main_menu()
    End Sub

    '**************************************************************************************
    'Makes main menu work, cursor position and newlines make me want to dead
    Sub Main_menu()
        Console.BackgroundColor = ConsoleColor.Black
        Console.Clear()
        Console.CursorVisible = False

        'ASCII art title
        Console.SetCursorPosition(8, 1)
        Console.WriteLine("                          ___         __        _________       __    ___     ________      _____________")
        Console.SetCursorPosition(8, 2)
        Console.WriteLine("#####################    |   \       |  |      /         \     |  |  /  /    |        |    |             |")
        Console.SetCursorPosition(8, 3)
        Console.WriteLine("#                        |    \      |  |     /  ______   \    |  | /  /     |   _____|    |   __________|")
        Console.SetCursorPosition(8, 4)
        Console.WriteLine("#                        |     \     |  |    |  |      |  |    |  |/  /      |  |_____     |  |_________")
        Console.SetCursorPosition(8, 5)
        Console.WriteLine("#                        |  |\  \    |  |    |  |______|  |    |     /       |        |    |            |")
        Console.SetCursorPosition(8, 6)
        Console.WriteLine("#####################    |  | \  \   |  |    |            |    |    |        |   _____|    |_________   |")
        Console.SetCursorPosition(8, 7)
        Console.WriteLine("                    #    |  |  \  \  |  |    |   ______   |    |     \       |  |                    |  |")
        Console.SetCursorPosition(8, 8)
        Console.WriteLine("                    #    |  |   \  \ |  |    |  |      |  |    |  |\  \      |  |_____      _________|  |")
        Console.SetCursorPosition(8, 9)
        Console.WriteLine("                    #    |  |    \  \|  |    |  |      |  |    |  | \  \     |        |    |            |")
        Console.SetCursorPosition(8, 10)
        Console.WriteLine("#####################    |__|     \_____|    |__|      |__|    |__|  \__\    |________|    |____________|")

        'Options
        Console.SetCursorPosition(8, 17)
        Console.Write("1. Play")
        Console.SetCursorPosition(8, 19)
        Console.Write("2. Options")
        Console.SetCursorPosition(8, 21)
        Console.Write("3. Shop")
        Console.SetCursorPosition(8, 23)
        Console.WriteLine("4. Credits")

        Do
            menuOption = 0
            get_input()
        Loop Until menuOption <> 0 And menuOption <= 4

        Select Case menuOption
            Case = 1
                Difficulty_menu()
            Case = 2
                Options()
            Case = 3
                Shop()
            Case = 4
                Credits()
        End Select

    End Sub

    '******************************************************************************
    'State your power level
    Sub Difficulty_menu()

        Console.Clear()
        Console.SetCursorPosition(5, 5)


        Console.Write("Choose the level of pain you wish to endure:")

        Console.SetCursorPosition(9, 8)
        Console.Write("1. Easy")
        Console.SetCursorPosition(9, 10)
        Console.Write("2. Normal")
        Console.SetCursorPosition(9, 12)
        Console.Write("3. Hard")
        Console.SetCursorPosition(9, 14)
        Console.Write("4. You do you")
        difficulty = 0
        Do
            get_input()
        Loop Until difficulty <> 0
    End Sub

    '*********************************************************************************
    'allow the user to change settings
    Sub Options()
        Dim key As Char
        Console.Clear()
        Console.Write("This is in progress, you are stuck here for now sorry

Press any button to get out of this hell hole.")
        key = Console.ReadKey.KeyChar
        Main_menu()
    End Sub

    '*********************************************************************************
    'allow the user to buy things, someone elses job
    Sub Shop()
        Dim key As Char
        Console.Clear()
        Console.Write("This is in progress, you are stuck here for now sorry

Press any button to get out of this hell hole.")
        key = Console.ReadKey.KeyChar
        Main_menu()
    End Sub

    '*********************************************************************************
    'meet your maker
    Sub Credits()
        Dim key As Char
        Console.Clear()
        Console.SetCursorPosition(8, 1)
        Console.WriteLine("                          ___         __        _________       __    ___     ________      _____________")
        Console.SetCursorPosition(8, 2)
        Console.WriteLine("#####################    |   \       |  |      /         \     |  |  /  /    |        |    |             |")
        Console.SetCursorPosition(8, 3)
        Console.WriteLine("#                        |    \      |  |     /  ______   \    |  | /  /     |   _____|    |   __________|")
        Console.SetCursorPosition(8, 4)
        Console.WriteLine("#                        |     \     |  |    |  |      |  |    |  |/  /      |  |_____     |  |_________")
        Console.SetCursorPosition(8, 5)
        Console.WriteLine("#                        |  |\  \    |  |    |  |______|  |    |     /       |        |    |            |")
        Console.SetCursorPosition(8, 6)
        Console.WriteLine("#####################    |  | \  \   |  |    |            |    |    |        |   _____|    |_________   |")
        Console.SetCursorPosition(8, 7)
        Console.WriteLine("                    #    |  |  \  \  |  |    |   ______   |    |     \       |  |                    |  |")
        Console.SetCursorPosition(8, 8)
        Console.WriteLine("                    #    |  |   \  \ |  |    |  |      |  |    |  |\  \      |  |_____      _________|  |")
        Console.SetCursorPosition(8, 9)
        Console.WriteLine("                    #    |  |    \  \|  |    |  |      |  |    |  | \  \     |        |    |            |")
        Console.SetCursorPosition(8, 10)
        Console.WriteLine("#####################    |__|     \_____|    |__|      |__|    |__|  \__\    |________|    |____________|")

        Console.SetCursorPosition(5, 15)
        Console.WriteLine("Credits:")
        Console.SetCursorPosition(5, 17)
        Console.WriteLine("Original Creator:")
        Console.SetCursorPosition(10, 18)
        Console.WriteLine(" - The Nokia 3350")
        Console.SetCursorPosition(5, 19)
        Console.WriteLine("Code Dad:")
        Console.SetCursorPosition(10, 20)
        Console.WriteLine(" - Craig Sargent")
        Console.SetCursorPosition(5, 21)
        Console.WriteLine("Other people who did things:")
        Console.SetCursorPosition(10, 22)
        Console.WriteLine(" - Alex Gowler")
        Console.SetCursorPosition(10, 23)
        Console.WriteLine(" - Kurtis Jackson")
        Console.SetCursorPosition(5, 24)
        Console.WriteLine("People who did things maybe but they sure aren't here right now:")
        Console.SetCursorPosition(10, 25)
        Console.WriteLine(" - Alex Tocknell")
        Console.SetCursorPosition(10, 26)
        Console.WriteLine(" - Emma Luff")
        Console.SetCursorPosition(10, 27)
        Console.WriteLine(" - Madeleine Nielsen")

        Console.SetCursorPosition(5, 30)
        Console.WriteLine("If you wish to identify as a different name say now")

        Console.SetCursorPosition(5, 32)
        Console.WriteLine("Chief Make game look better -er:")
        Console.SetCursorPosition(10, 33)
        Console.WriteLine(" - Kurtis Jackson")
        Console.SetCursorPosition(10, 34)
        Console.WriteLine(" - One really exciting Tuesday afternoon")
        Console.SetCursorPosition(5, 35)
        Console.WriteLine("Special thanks:")
        Console.SetCursorPosition(10, 36)
        Console.WriteLine(" - Microsoft Office for making me spell the names right")
        Console.SetCursorPosition(10, 37)
        Console.WriteLine(" - Whoever makes this scroll, thanks. Oh yea can you also make this look better.")

        Console.SetCursorPosition(5, 40)
        Console.WriteLine("Press any button to go back to the main menu.")
        Console.SetCursorPosition(5, 41)
        Console.WriteLine("At this point I want it to stop scrolling and only 'press any button blah blah' be on screen.")

        key = Console.ReadKey.KeyChar
        Main_menu()
    End Sub

    '*********************************************************************************
    'Procedure to display the arena
    Sub display_arena()
        Dim counterx, countery As Integer
        Console.CursorVisible = False
        Console.Clear()
        Console.SetCursorPosition(55, 2)
        Console.ForegroundColor() = ConsoleColor.Green
        Console.Write("Score: " & score)
        Console.SetCursorPosition(55, 4)
        Console.Write("Bonus: 200")
        For counterx = 0 To 49
            For countery = 0 To 23
                Console.BackgroundColor = 14
                Console.SetCursorPosition(counterx, countery)
                Console.Write(arena(counterx, countery))

            Next
        Next
        For counterx = 1 To 48
            For countery = 1 To 22
                Console.BackgroundColor = ConsoleColor.DarkBlue
                Console.SetCursorPosition(counterx, countery)
                Console.Write(arena(counterx, countery))
            Next
        Next
    End Sub

    '*************************************************************************************
    'Procedure to get the input from the keyboard buffer
    Sub get_input()
        Dim key As System.ConsoleKeyInfo
        If Console.KeyAvailable Then key = Console.ReadKey(True)
        If ((key.KeyChar = "a") And (wormDirection <> "r")) Then wormDirection = "l"
        If ((key.KeyChar = "w") And (wormDirection <> "d")) Then wormDirection = "u"
        If ((key.KeyChar = "s") And (wormDirection <> "u")) Then wormDirection = "d"
        If ((key.KeyChar = "d") And (wormDirection <> "l")) Then wormDirection = "r"

        'game pause
        If ((key.Key = ConsoleKey.Escape)) Then
            pause = Not (pause)
        End If

        'difficulty menu
        If difficulty = 0 Or menuOption = 0 Then
            Select Case key.KeyChar
                Case "1"
                    difficulty = 1
                    menuOption = 1
                Case "2"
                    difficulty = 2
                    menuOption = 2
                Case "3"
                    difficulty = 3
                    menuOption = 3
                Case "4"
                    difficulty = 4
                    menuOption = 4
            End Select

        End If
    End Sub

    '***************************************************************************************
    'Procudure to detect worm collisions with objects and keep score
    Sub collosion_detection_and_score()
        Dim difspeed As Double
        Select Case difficulty
            Case = 1
                difspeed = 0.5
            Case = 2
                difspeed = 1
            Case = 3
                difspeed = 2
            Case = 4
                difspeed = 5
        End Select
        If bonusLevel = False Then
            If arena(worm(wormHeadPointer, 1), worm(wormHeadPointer, 2)) = "+" Then
                wormGrow = True
                score = score + 10 + foodTimer
                Console.SetCursorPosition(55, 2)
                Console.Write("Score: {0}", score)
                gameSpeed = gameSpeed - difspeed
                drop_food()
            End If
        Else
            Dim color As Byte
            If arena(worm(wormHeadPointer, 1), worm(wormHeadPointer, 2)) = "+" Then
                'lowers count of bonus fruit by one to signal end of bonus levle
                bonusFruitCount = bonusFruitCount - 1
                'code to make worm grow once every 10 fruits so you don't grow exponetially
                If bonusFruitCount Mod 100 = 0 Then
                    wormGrow = True
                End If

                'default scoring algorithm  
                score = score + 10 + foodTimer
                Console.SetCursorPosition(55, 2)
                Console.Write("Score: {0}", score)

                ' BONUS LEVEL EXCLUSIVE generates random integer from 1-15 to correspond with a .net console colour enum value (excluding 0 & 15 - black & white)
                color = Rnd() * 14
                Console.BackgroundColor = color


            End If
            bonusLevelDone = True
        End If

        If arena(worm(wormHeadPointer, 1), worm(wormHeadPointer, 2)) = "#" Then
            wormAlive = False
        End If
        If arena(worm(wormHeadPointer, 1), worm(wormHeadPointer, 2)) = "!" Then
            wormAlive = False
        End If
    End Sub

    '*********************************************************************************************************************
    'pauses the game
    Sub pause_game()
        If pause = True Then
            Dim counterX As SByte
            Console.SetCursorPosition(16, 12)
            Console.WriteLine("G A M E   P A U S E D")
            Do
                get_input()
            Loop Until pause = False
            For counterX = 16 To 37
                Console.SetCursorPosition(counterX, 12)
                Console.Write(arena(counterX, 12))
            Next
            If arena(xFood, yFood) <> "+" Then
                Console.SetCursorPosition(xFood, yFood)
                Console.Write("+")
            End If

        End If
    End Sub

    '***************************************************************************************
    'Procudure to move the worm
    Sub move_worm()
        Dim wormHeadX, wormHeadY As Integer
        'calculate the new head position
        wormHeadX = worm(wormHeadPointer, 1)
        wormHeadY = worm(wormHeadPointer, 2)
        wormHeadPointer = wormHeadPointer + 1
        If (wormHeadPointer = 100) Then wormHeadPointer = 0
        Select Case wormDirection
            Case "r"
                wormHeadX = wormHeadX + 1
            Case "l"
                wormHeadX = wormHeadX - 1
            Case "u"
                wormHeadY = wormHeadY - 1
            Case "d"
                wormHeadY = wormHeadY + 1
        End Select
        'wrap the worm around the screen if needed
        If (wormHeadX = 50) Then wormHeadX = 0
        If (wormHeadX = -1) Then wormHeadX = 49
        If (wormHeadY = -1) Then wormHeadY = 23
        If (wormHeadY = 24) Then wormHeadY = 0
        'set the new worm head position
        worm(wormHeadPointer, 1) = wormHeadX
        worm(wormHeadPointer, 2) = wormHeadY
        collosion_detection_and_score()
        arena(wormHeadX, wormHeadY) = "#"
        'draw the new worm head
        Console.ForegroundColor() = 15
        Console.SetCursorPosition(worm(wormHeadPointer, 1), worm(wormHeadPointer, 2))
        Console.Write("#")
        'delete the segment from the tail
        If wormGrow = False Then
            Console.SetCursorPosition(worm(wormTailPointer, 1), worm(wormTailPointer, 2))
            Console.Write(" ")
            arena(worm(wormTailPointer, 1), worm(wormTailPointer, 2)) = " "
            wormTailPointer = wormTailPointer + 1
            If wormTailPointer = 100 Then wormTailPointer = 0
        Else
            wormGrow = False
        End If
    End Sub

    '************************************************************************************
    'Procedure to display the game over message and get the high score name
    Sub game_over_message()
        Dim key As Char
        key = Nothing
        For counterX = 0 To 49
            For counterY = 0 To 23
                arena(counterX, counterY) = " "
            Next
        Next
        For counterx = 0 To 49
            For countery = 0 To 23
                Console.BackgroundColor = ConsoleColor.Black
                Console.SetCursorPosition(counterx, countery)
                Console.Write(arena(counterx, countery))

            Next
        Next
        Console.ForegroundColor() = 12
        Console.SetCursorPosition(17, 1)
        Console.Write("
 _______________
|  |            \      __________        __________ 
|  |   _____     |    /          \      /          \
|  |  |     |    |   /            \    /            \
|  |  |_____|    |  |    _____    |   |    _____    |
|  |             |  |   |     |   |   |   |     |   |
|  |     _______/   |   |     |   |   |   |     |   |
|  |            \   |   |     |   |   |   |     |   |
|  |   _____     |  |   |_____|   |   |   |_____|   |
|  |  |     |    |  |             |   |             |
|  |  |_____|    |  |             |   |             |
|  |             |   \           /     \           /
|__|____________/     \_________/       \_________/
                       YOU STINK")
        System.Threading.Thread.Sleep(3000)
        Console.SetCursorPosition(16, 20)
        Console.Write("Press any key to continue")
        key = Console.ReadKey.KeyChar
    End Sub

    '************************************************************************************
    'Procedure to compute and to display the high score value
    Sub high_scores()
        Dim counter1, counter2 As Integer
        Dim key As Char
        Dim isHighScore As Boolean
        Dim name As String

        'initialise local variables
        Console.ForegroundColor = 13
        isHighScore = False
        counter1 = 0
        key = Nothing

        'check if this score was set by Craig Sargent
        Do
            If (score > highscoreValue(counter1)) Then isHighScore = True
            If (isHighScore <> True) Then counter1 = counter1 + 1
        Loop Until (counter1 = 9) Or (isHighScore = True)

        'if it is a high score, ask for name and add to list
        If isHighScore = True Then
            Console.Clear()
            Console.SetCursorPosition(5, 5)
            Console.Write("temporary you done did a high score message, hazaa")
            Console.SetCursorPosition(5, 7)
            Console.Write("Please enter your name: ")
            name = Console.ReadLine()
            'move the other scores down one place
            For counter2 = 9 To counter1 + 1 Step -1
                highscoreName(counter2) = highscoreName(counter2 - 1)
                highscoreValue(counter2) = highscoreValue(counter2 - 1)
            Next

            'add high score to list
            highscoreName(counter1) = name
            highscoreValue(counter1) = score
        End If

        'put score on screen thanks
        Console.Clear()
        Console.SetCursorPosition(5, 5)
        Console.Write("High score message, you guessed it also temporary")
        For counter1 = 0 To 9
            Console.SetCursorPosition(5, 7 + counter1)
            Console.Write(highscoreName(counter1))
            Console.SetCursorPosition(20, 7 + counter1)
            Console.Write(highscoreValue(counter1))
        Next
        Console.SetCursorPosition(5, 23)
        Console.Write("Press a key to play again, you don't have an option.")
        key = Console.ReadKey.KeyChar
    End Sub

    '************************************************************************************
    'Procedure to reduce the food bonus timer
    Sub update_food()
        If (foodTimer > 0) Then
            foodTimer = foodTimer - 1
        End If
        Console.SetCursorPosition(55, 4)
        Console.BackgroundColor = ConsoleColor.Black
        Console.Write("Bonus: {0}", foodTimer)
    End Sub

    '*********************************************************************************************
    'no snitching, no surrender
    Sub bonus_level()
        Dim counter1 As Int16

        If score > bonusLevelScore And bonusLevelDone = False Then 'And gameSpeed < 49

            bonusLevel = True

            For counter1 = 1 To 10

                Console.SetCursorPosition(8, 12)
                Console.WriteLine("B O N U S   L E V E L   U N L O C K E D")
                Threading.Thread.Sleep(100)
                For counterx = 8 To 49
                    Console.SetCursorPosition(counterx, 12)
                    Console.Write(arena(counterx, 12))

                Next
                Threading.Thread.Sleep(100)
            Next
            If arena(xFood, yFood) <> "+" Then
                Console.SetCursorPosition(xFood, yFood)
                Console.Write("+")
            End If


            For counter1 = 1 To 300
                drop_food()
            Next
            bonusFruitCount = 300

        End If

        If bonusLevel = True Then
            If bonusFruitCount = 0 Then
                Console.SetCursorPosition(55, 8)
                Console.Write("Bonus level ended")
                reset_colours()
                bonusLevel = False
                bonusLevelDone = True
            End If
        End If
    End Sub

    '***********************************************************************************
    'keeps that backdrop jazzy
    Sub reset_colours()
        For counterx = 0 To 49
            For countery = 0 To 23
                Console.BackgroundColor = 14
                Console.SetCursorPosition(counterx, countery)
                Console.Write(arena(counterx, countery))

            Next
        Next
        For counterx = 1 To 48
            For countery = 1 To 22
                Console.BackgroundColor = ConsoleColor.DarkBlue
                Console.SetCursorPosition(counterx, countery)
                Console.Write(arena(counterx, countery))
            Next
        Next
    End Sub

    '************************************************************************************
    'Keep colours jazzy
    Sub background_retainer()
        ' Dim arenaX, arenaY As Integer
        'calculate the current head position
        ' arenaX = arena(wormHeadPointer, 1)
        ' arenaY = arena(wormHeadPointer, 2)

        Console.SetCursorPosition(55, 2)
        Console.ForegroundColor() = 1
        Console.BackgroundColor = 0
        Console.Write("Score: " & score)
        Console.BackgroundColor = 1
    End Sub

    '*************************************************************************************
    'Main program starts here
    Sub Main()
        Menu_transition()
        initialise_high_score()
        Do
            initialise_game()
            display_arena()
            Do
                System.Threading.Thread.Sleep(gameSpeed)
                background_retainer()
                get_input()
                move_worm()
                get_input()
                update_food()
                drop_wall()
            Loop Until (wormAlive = False)
            game_over_message()
            high_scores()
        Loop Until (forever)
    End Sub

End Module
